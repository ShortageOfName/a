import asyncio
import time
from urllib.parse import urlparse, parse_qs, urlencode, urlunparse
from playwright.async_api import async_playwright, TimeoutError as PlaywrightTimeoutError
import sys

CHK_URL = sys.argv[2]
CARDZ = sys.argv[1]

class CaptchaDetectedException(Exception):
    pass


class ThreeDSDetectedException(Exception):
    """Exception raised when 3D Secure authentication is detected."""
    pass


async def check_for_captcha(page):
    if await page.query_selector('iframe[src*="recaptcha"]') or await page.query_selector('iframe[src*="hcaptcha.com"]'):
        return True, "CAPTCHA (reCAPTCHA or hCaptcha) is present!"
    try:
        if await page.query_selector('text="Complete the CAPTCHA to continue"') or await page.get_by_text("Complete the CAPTCHA to continue").count() > 0:
            return True, "Text-based CAPTCHA detected: 'Complete the CAPTCHA to continue'"
    except Exception:
        pass
    try:
        page_content = await page.content()
        if "Complete the CAPTCHA to continue" in page_content:
            return True, "CAPTCHA detected in page content: 'Complete the CAPTCHA to continue'"
    except Exception:
        pass
    return False, ""


async def check_for_3ds(page):
    try:
        if await page.query_selector('iframe[src*="stripe/authentications"]'):
            return True, f"Response: 3Ds"
            
        return False, ""
    except Exception as e:
        print(f"Error 3DS: {e}")
        return False, ""


async def run_shopify_checkout():
    STIME = time.time()
    stop_event = asyncio.Event()
    card_parts = CARDZ.split('|')
    card_number = card_parts[0]
    expiry = card_parts[1]
    cvv = card_parts[2]
    
    playwright = await async_playwright().start()
    browser = await playwright.chromium.launch(
        headless=True,
        args=[
            '--disable-gpu', '--disable-dev-shm-usage', '--disable-extensions',
            '--disable-setuid-sandbox', '--no-sandbox', '--disable-features=site-per-process',
            '--disable-accelerated-2d-canvas', '--disable-accelerated-video-decode',
            '--disable-web-security', '--mute-audio',
        ]
    )
    
    try:
        page = await browser.new_page()
        await page.goto(CHK_URL, wait_until="domcontentloaded")
        await page.wait_for_url("**/checkouts/**", timeout=17000)
        
        parsed = urlparse(page.url)
        query = parse_qs(parsed.query)
        query.pop('auto_redirect', None)
        query.pop('edge_redirect', None)
        CLNDQRY = urlencode(query, doseq=True)
        CLNDURL = urlunparse(parsed._replace(query=CLNDQRY))
        
        await page.goto(CLNDURL, wait_until="domcontentloaded")
        await asyncio.sleep(3)
        
        captcha_detected, message = await check_for_captcha(page)
        if captcha_detected:
            print(f"\n{message}")
            print("CAPTCHA detected! Stopping all operations.")
            return
        
        async def continuous_security_check():
            while not stop_event.is_set():
                try:
                    captcha_detected, captcha_message = await check_for_captcha(page)
                    if captcha_detected:
                        print(f"\n{captcha_message}")
                        print("CAPTCHA detected! Stopping all operations.")
                        stop_event.set()
                        return True, "CAPTCHA"
                    
                    threeDS_detected, threeDS_message = await check_for_3ds(page)
                    if threeDS_detected:
                        print(f"{threeDS_message}")
                        stop_event.set()
                        return True, "3DS"
                    
                    await asyncio.sleep(1)
                except Exception as e:
                    print(f"Error in security check: {e}")
                    await asyncio.sleep(1)
            return False, ""
        
        SCTASK = asyncio.create_task(continuous_security_check())
        
        async def process_checkout():
            try:
                if not stop_event.is_set():
                    try:
                        await page.fill('input[name="phone"]', "+91-1234567890")
                    except Exception:
                        print("Phone field not found or could not be filled")
                
                if not stop_event.is_set():
                    try:
                        await page.frame_locator("iframe[name^='card-fields-number']").locator("input[name='number']").fill(card_number)
                        await page.frame_locator("iframe[name^='card-fields-name']").locator("input[name='name']").fill("Robert Hofman")
                        await page.frame_locator("iframe[name^='card-fields-expiry']").locator("input[name='expiry']").fill(expiry)
                        await page.frame_locator("iframe[name^='card-fields-verification_value']").locator("input[name='verification_value']").fill(cvv)
                    except Exception as e:
                        print(f"Error filling card details: {e}")
                
                if not stop_event.is_set():
                    try:
                        async with page.expect_navigation(timeout=15000):
                            await page.click("button[type='submit']")
                        try:
                            await page.wait_for_function(
                                "() => !window.location.href.includes('/processing')",
                                timeout=15000
                            )
                        except PlaywrightTimeoutError:
                            pass
                    except Exception as e:
                        print(f"Error submitting payment: {e}")
                        return False, "Failed to submit payment"
                
                if not stop_event.is_set():
                    try:
                        await page.wait_for_selector("body", timeout=10000)
                    except PlaywrightTimeoutError:
                        pass
                    visible_text = await page.content()
                    
                    ALIVEMSG = ["Thank you for your purchase!", "Your order is confirmed.", "Payment successful.", "Thank You", "onfirmed"]
                    DEATHMSG = {
                        "Your card was declined. Try again or use a different payment method.": "Card was declined",
                        "Your card has insufficient funds.": "Insufficient funds",
                        "Your card has expired.": "Card expired",
                        "The CVC number is incorrect.": "Incorrect CVV",
                        "The card number is incorrect.": "Incorrect card number",
                        "An error occurred while processing your card. Try again.": "Processing error",
                        "Your card was declined.": "Card lost or stolen",
                        "Your card was declined. Contact your bank for more information.": "Do not honor/Incorrect zip code",
                        "Your card does not support this type of purchase.": "Card not supported"
                    }
                    
                    for word in ALIVEMSG:
                        if word.lower() in visible_text.lower():
                            return True, "Payment is completed"
                    for message, reason in DEATHMSG.items():
                        if message.lower() in visible_text.lower():
                            return False, f"Payment declined: {reason}"
                    return False, "Unknown outcome, no clear indicators"
                
                return False, "Operation stopped"
            except Exception as e:
                return False, f"Error during checkout: {e}"
        
        CHKOTTASK = asyncio.create_task(process_checkout())
        
        done, pending = await asyncio.wait(
            [SCTASK, CHKOTTASK],
            return_when=asyncio.FIRST_COMPLETED
        )
        
        for task in pending:
            task.cancel()
            try:
                await task
            except asyncio.CancelledError:
                pass
        
        if SCTASK in done:
            detected, check_type = SCTASK.result()
            if detected and check_type == "3DS":
                pass
        elif CHKOTTASK in done:
            success, message = CHKOTTASK.result()
            print(f"\n{message}")
        
    except Exception as e:
        print(f"\nAn error occurred: {e}")
    finally:
        await browser.close()
        await playwright.stop()
        
        end_time = time.time()
        #print(f"Total time taken: {end_time - STIME:.2f} seconds")


async def main():
    try:
        await run_shopify_checkout()
    except KeyboardInterrupt:
        print("\nOperation cancelled by user.")
    except Exception as e:
        print(f"\nUnexpected error: {e}")


if __name__ == "__main__":
    asyncio.run(main())