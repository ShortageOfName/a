from telethon import TelegramClient, events
import subprocess
import os
import json
from urllib.parse import urlparse

APIid = "22157690"
APIhash = "819a20b5347be3a190163fff29d59d81"
BOTtokn = '6792868671:AAEzELb-EMEAMYERlb7sDZ2kmjFeX1JdRpY'

CHAINsmokr = [5439878112, 2092103173]

client = TelegramClient('bot', APIid, APIhash).start(bot_token=BOTtokn)

base_dir = os.path.dirname(os.path.abspath(__file__))
APPI = os.path.join(base_dir, 'api.py')
JSON = os.path.join(base_dir, 'site.json')
S2CHKOTpath = os.path.join(base_dir, 's2chkot.py')

def QMAIN(card_details, SURL, price=None):
    try:
        cmd = ['python', APPI, card_details, SURL]
        if price:
            cmd.append(price)
        result = subprocess.run(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
        output = result.stdout.strip() + '\n' + result.stderr.strip()
        print(f"[api.py output for {card_details} on {SURL} (price: {price})]:\n{output}")
        return output.strip()
    except Exception as e:
        print(f"[Subprocess Exception]: {e}")
        return str(e)

def GDATA():
    if not os.path.isfile(JSON):
        print(f"Site JSON file not found: {JSON}")
        return []
    try:
        with open(JSON, 'r') as f:
            data = json.load(f) 
        if isinstance(data, list):
            SITED = []
            for entry in data:
                if isinstance(entry, list) and len(entry) >= 1:
                    site = entry[0]
                    price = entry[1] if len(entry) > 1 else None
                    SITED.append((site, price))
                else:
                    print(f"Skipping invalid entry: {entry}")
            return SITED
        else:
            print("Unexpected JSON format. Expected a list of [site, price] entries.")
            return []
    except json.JSONDecodeError as e:
        print(f"Error parsing JSON file: {e}")
        return []
    except Exception as e:
        print(f"Error reading site data: {e}")
        return []

def is_premium(user_id):
    return user_id in CHAINsmokr

@client.on(events.NewMessage(pattern='/chk'))
async def handle_chk(event):
    sender = await event.get_sender()
    if not is_premium(sender.id):
        await event.respond("🚫 gay are not allowed send this chat's screenshot to confirm you are gay.")
        return

    user_message = event.message.text.strip()
    card_details = user_message.replace("/chk", "").strip()
    SITED = GDATA()
    if not SITED:
        await event.reply("❌ site.json not found or is empty.")
        return
    CLIST = card_details.split()
    for card in CLIST:
        CINDEX = 0
        retry = True
        while retry:
            if CINDEX >= len(SITED):
                await event.respond(f"❌ No more sites to try for `{card}`.")
                break
            SURL, price = SITED[CINDEX]
            result = QMAIN(card, SURL, price)
            if "CAPTCHA" in result.upper():
                await event.respond(f"⚠️ CAPTCHA on {SURL}, switching to next for `{card}`.")
                CINDEX += 1
            else:
                price_info = price if price else "N/A"
                FUCKEDURL = urlparse(SURL)
                base_SURL = f"{FUCKEDURL.scheme}://{FUCKEDURL.netloc}{FUCKEDURL.path}"
                FRESULT = (
                    f"**Card:** `{card}`\n"
                    f"**Site:** `{base_SURL}`\n"
                    f"**Price:** `{price_info}`\n\n"
                    f"**Response:**"
                    f"```\n{result}\n```"
                )
                await event.respond(FRESULT, parse_mode='Markdown')
                retry = False

@client.on(events.NewMessage(pattern=r'^/site (.+)'))
async def handle_site_command(event):
    sender = await event.get_sender()
    if not is_premium(sender.id):
        await event.respond("🚫 gay are not allowed send this chat's screenshot to confirm you are gay.")
        return

    url = event.pattern_match.group(1).strip()
    if not url:
        await event.respond("❌ Please provide a URL.\nUsage: `/site https://example.com`")
        return

    try:
        result = subprocess.run(
            ['python', S2CHKOTpath, url],
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=True
        )
        output = result.stdout.strip() + '\n' + result.stderr.strip()
        if not output.strip():
            output = "⚠️ No output from script."
        response = f"**URL:** `{url}`\n\n**Result:**\n```\n{output}\n```"
        await event.respond(response, parse_mode='Markdown')
    except Exception as e:
        await event.respond(f"❌ Error running script:\n`{str(e)}`")

client.start()
print("🤖is this bot running...??")
client.run_until_disconnected()
