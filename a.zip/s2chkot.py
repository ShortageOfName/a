import json
import os
import requests
import sys

SURL = sys.argv[1]
OFILE = "a.json"
page = 1
VALIDVAR = []
USELESSids = set()

while True:
    url = f"{SURL}/products.json?limit=250&page={page}"
    res = requests.get(url)

    if res.status_code != 200:
        print("Failed to fetch data or blocked by the store.")
        break

    products = res.json().get("products", [])
    if not products:
        break

    for product in products:
        product_id = product.get("id")
        if product_id in USELESSids:
            continue
        USELESSids.add(product_id)

        for variant in product.get("variants", []):
            try:
                price = float(variant.get("price", 0)) + float(27)
                available = variant.get("available", False)
                variant_id = variant.get("id")

                if price > 0.99 and available:
                    VALIDVAR.append({
                        "product_id": product_id,
                        "variant_id": variant_id,
                        "title": product.get("title"),
                        "price": price
                    })
                    break
            except (ValueError, TypeError):
                continue

    page += 1

VALIDVAR.sort(key=lambda x: x["price"])

output_data = []

for item in VALIDVAR[:1]:
    variant_id = item["variant_id"]
    price = item["price"]
    checkout_url = (
        f"{SURL}/cart/{variant_id}:1"
        "?checkout[email]=bitaca9757@astimei.com"
        "&checkout[shipping_address][first_name]=John"
        "&checkout[shipping_address][last_name]=Doe"
        "&checkout[shipping_address][address1]=123%20Main%20St"
        "&checkout[shipping_address][address2]=Apt%204"
        "&checkout[shipping_address][city]=New%20York"
        "&checkout[shipping_address][province]=New%20York"
        "&checkout[shipping_address][zip]=10080"
        "&checkout[shipping_address][country]=United%20States"
    )
    output_data.append([checkout_url, f"{price}"])

if os.path.isfile(OFILE):
    with open(OFILE, "r") as f:
        existing_data = json.load(f)
else:
    existing_data = []
existing_data.extend(output_data)
with open(OFILE, "w") as f:
    json.dump(existing_data, f, indent=2)
print(f"Saved to {OFILE}:")
for entry in output_data:
    print(entry)
